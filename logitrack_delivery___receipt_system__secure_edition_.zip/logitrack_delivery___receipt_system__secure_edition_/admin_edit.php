<?php
require 'config.php';
checkAuth('admin');

$id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
if (!$id) { set_flash('danger', 'ข้อมูลไม่ถูกต้อง'); header('Location: admin_dashboard.php'); exit; }

$stmt = $pdo->prepare("SELECT * FROM orders WHERE id = ?");
$stmt->execute([$id]);
$order = $stmt->fetch();
if (!$order) { set_flash('danger', 'ไม่พบข้อมูลที่ต้องการแก้ไข'); header('Location: admin_dashboard.php'); exit; }

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf_token($_POST['csrf_token'] ?? '');
    
    $s_dept = trim($_POST['sender_dept']);
    $s_phone = trim($_POST['sender_phone']);
    $r_dept = trim($_POST['receiver_dept']);
    $r_phone = trim($_POST['receiver_phone']);
    $details = trim($_POST['product_details']);
    $status = $_POST['status'];
    
    $valid_statuses = ['pending', 'delivering', 'delivered', 'cancelled'];
    if (!in_array($status, $valid_statuses)) $status = 'pending';

    if (!validate_phone($s_phone) || !validate_phone($r_phone)) {
        set_flash('danger', 'กรุณากรอกเบอร์โทรศัพท์ให้ถูกต้อง');
    } else {
        $upd = $pdo->prepare("UPDATE orders SET sender_dept=?, sender_phone=?, receiver_dept=?, receiver_phone=?, product_details=?, status=? WHERE id=?");
        if ($upd->execute([$s_dept, $s_phone, $r_dept, $r_phone, $details, $status, $id])) {
            set_flash('success', 'บันทึกการแก้ไขเรียบร้อย');
            header("Location: admin_dashboard.php");
            exit;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="th">
<head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0"><title>แก้ไขข้อมูล | LogiTrack</title><link rel="stylesheet" href="style.css"></head>
<body>
<div class="container">
    <div class="card" style="max-width: 600px; margin: 0 auto;">
        <h2>แก้ไขข้อมูลรายการจัดส่ง</h2>
        <?php display_flash(); ?>
        <form method="POST">
            <input type="hidden" name="csrf_token" value="<?php echo h(generate_csrf_token()); ?>">
            <div class="form-group"><label>รหัสสินค้า (Barcode)</label><input type="text" value="<?php echo h($order['barcode']); ?>" readonly disabled style="background:#f3f4f6;"></div>
            <div class="form-group"><label>ชื่อแผนกส่ง</label><input type="text" name="sender_dept" value="<?php echo h($order['sender_dept']); ?>" required></div>
            <div class="form-group"><label>เบอร์โทรศัพท์ผู้ส่ง</label><input type="text" name="sender_phone" value="<?php echo h($order['sender_phone']); ?>" required pattern="[0-9]{9,10}"></div>
            <div class="form-group"><label>แผนกผู้รับ</label><input type="text" name="receiver_dept" value="<?php echo h($order['receiver_dept']); ?>" required></div>
            <div class="form-group"><label>เบอร์โทรศัพท์ผู้รับ</label><input type="text" name="receiver_phone" value="<?php echo h($order['receiver_phone']); ?>" required pattern="[0-9]{9,10}"></div>
            <div class="form-group"><label>รายละเอียดสินค้า</label><textarea name="product_details" rows="4" required><?php echo h($order['product_details']); ?></textarea></div>
            <div class="form-group"><label>สถานะการจัดส่ง</label>
                <select name="status">
                    <option value="pending" <?php if($order['status']=='pending') echo 'selected'; ?>>Pending (รอดำเนินการ)</option>
                    <option value="delivering" <?php if($order['status']=='delivering') echo 'selected'; ?>>Delivering (กำลังจัดส่ง)</option>
                    <option value="delivered" <?php if($order['status']=='delivered') echo 'selected'; ?>>Delivered (ส่งสำเร็จ)</option>
                    <option value="cancelled" <?php if($order['status']=='cancelled') echo 'selected'; ?>>Cancelled (ยกเลิก)</option>
                </select>
            </div>
            <div style="display:flex; gap:10px; margin-top:20px;">
                <button type="submit" class="btn-success" style="flex:1;">บันทึกการแก้ไข</button>
                <a href="admin_dashboard.php" class="btn btn-danger" style="flex:1; text-align:center;">ยกเลิก</a>
            </div>
        </form>
    </div>
</div>
</body>
</html>