<?php
require 'config.php';
checkAuth('admin');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf_token($_POST['csrf_token'] ?? '');
    
    $id = filter_input(INPUT_POST, 'id', FILTER_VALIDATE_INT);
    if ($id) {
        $stmt = $pdo->prepare("SELECT proof_image, signature_image FROM orders WHERE id = ?");
        $stmt->execute([$id]);
        $order = $stmt->fetch();
        
        if ($order) {
            $upload_dir = __DIR__ . '/uploads/';
            if (!empty($order['proof_image']) && file_exists($upload_dir . $order['proof_image'])) {
                @unlink($upload_dir . $order['proof_image']);
            }
            if (!empty($order['signature_image']) && file_exists($upload_dir . $order['signature_image'])) {
                @unlink($upload_dir . $order['signature_image']);
            }
            
            $del = $pdo->prepare("DELETE FROM orders WHERE id = ?");
            if ($del->execute([$id])) {
                set_flash('success', 'ลบข้อมูลและไฟล์แนบที่เกี่ยวข้องเรียบร้อยแล้ว');
            }
        }
    }
}
header("Location: admin_dashboard.php");
exit;
?>