<?php
function h($string) {
    return htmlspecialchars($string ?? '', ENT_QUOTES, 'UTF-8');
}

function generate_csrf_token() {
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

function verify_csrf_token($token) {
    if (!$token || !hash_equals($_SESSION['csrf_token'], $token)) {
        set_flash('danger', 'Security Error: ข้อมูลไม่ถูกต้อง โปรดทำรายการใหม่');
        header('Location: index.php');
        exit;
    }
}

function checkAuth($role = null) {
    if (empty($_SESSION['user_id'])) {
        header("Location: login.php");
        exit;
    }
    if ($role && $_SESSION['role'] !== $role) {
        header("HTTP/1.1 403 Forbidden");
        die("Access Denied: ไม่ได้รับสิทธิ์การเข้าถึงข้อมูลส่วนนี้");
    }
}

function validate_phone($phone) {
    return preg_match('/^[0-9]{9,10}$/', $phone);
}

function mask_phone($phone) {
    if (strlen($phone) < 9) return $phone;
    return substr($phone, 0, 3) . '-XXXX-' . substr($phone, -3);
}

function thai_date($datetime) {
    if (!$datetime) return '-';
    return date('d/m/Y H:i', strtotime($datetime));
}

function set_flash($type, $message) {
    $_SESSION['flash'] = ['type' => $type, 'message' => $message];
}

function display_flash() {
    if (isset($_SESSION['flash'])) {
        $f = $_SESSION['flash'];
        echo '<div class="alert alert-' . h($f['type']) . '">' . h($f['message']) . '</div>';
        unset($_SESSION['flash']);
    }
}
?>