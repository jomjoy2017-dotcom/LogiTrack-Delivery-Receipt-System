<?php
require 'config.php';
checkAuth('driver');

$id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
if (!$id) { set_flash('danger', 'ข้อมูลไม่ถูกต้อง'); header('Location: driver_dashboard.php'); exit; }

$stmt = $pdo->prepare("SELECT * FROM orders WHERE id = ?");
$stmt->execute([$id]);
$order = $stmt->fetch();
if (!$order) { set_flash('danger', 'ไม่พบข้อมูล'); header('Location: driver_dashboard.php'); exit; }

$error = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf_token($_POST['csrf_token'] ?? '');
    
    $status = $_POST['status'];
    if (!in_array($status, ['delivering', 'delivered'])) $status = 'delivering';
    
    $upload_dir = __DIR__ . '/uploads/';
    if (!is_dir($upload_dir)) mkdir($upload_dir, 0755, true);
    
    $proof_image = $order['proof_image'];
    if (isset($_FILES['proof_image']) && $_FILES['proof_image']['error'] === UPLOAD_ERR_OK) {
        $allowed_exts = ['jpg', 'jpeg', 'png'];
        $filename_parts = explode('.', $_FILES['proof_image']['name']);
        $ext = strtolower(end($filename_parts));
        
        if (in_array($ext, $allowed_exts)) {
            $finfo = finfo_open(FILEINFO_MIME_TYPE);
            $mime = finfo_file($finfo, $_FILES['proof_image']['tmp_name']);
            finfo_close($finfo);
            
            if (strpos($mime, 'image/') === 0) {
                $new_filename = bin2hex(random_bytes(16)) . '.' . $ext;
                if (move_uploaded_file($_FILES['proof_image']['tmp_name'], $upload_dir . $new_filename)) {
                    if (!empty($proof_image) && file_exists($upload_dir . $proof_image)) @unlink($upload_dir . $proof_image);
                    $proof_image = $new_filename;
                }
            } else {
                $error = "ไฟล์ที่อัปโหลดไม่ใช่รูปภาพที่ถูกต้อง";
            }
        } else {
            $error = "อนุญาตเฉพาะไฟล์นามสกุล JPG และ PNG เท่านั้น";
        }
    }

    $signature_image = $order['signature_image'];
    if (empty($error) && !empty($_POST['signature_data'])) {
        $sigData = $_POST['signature_data'];
        if (preg_match('/^data:image\/png;base64,/', $sigData)) {
            $sigData = str_replace('data:image/png;base64,', '', $sigData);
            $sigData = str_replace(' ', '+', $sigData);
            $decodedData = base64_decode($sigData, true);
            
            if ($decodedData !== false) {
                $sigFile = bin2hex(random_bytes(16)) . '_sig.png';
                if (file_put_contents($upload_dir . $sigFile, $decodedData)) {
                    if (!empty($signature_image) && file_exists($upload_dir . $signature_image)) @unlink($upload_dir . $signature_image);
                    $signature_image = $sigFile;
                }
            }
        }
    }
    
    if ($status === 'delivered') {
        if (empty($proof_image) || empty($signature_image)) {
            $error = "ไม่สามารถบันทึกสถานะ 'ส่งสำเร็จ' ได้ กรุณาถ่ายรูปหลักฐานและให้ผู้รับเซ็นชื่อให้ครบถ้วน";
        }
    }
    
    if (empty($error)) {
        $upd = $pdo->prepare("UPDATE orders SET status = ?, proof_image = ?, signature_image = ?, driver_id = ? WHERE id = ?");
        if ($upd->execute([$status, $proof_image, $signature_image, $_SESSION['user_id'], $id])) {
            set_flash('success', 'อัปเดตสถานะการจัดส่งสำเร็จ');
            header("Location: driver_dashboard.php");
            exit;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="th">
<head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0"><title>อัปเดตสถานะ e-POD | LogiTrack</title><link rel="stylesheet" href="style.css"></head>
<body>
<div class="container">
    <div class="card" style="max-width: 500px; margin: 0 auto;">
        <h2 style="text-align:center;">ระบบตรวจรับ e-POD</h2>
        <p style="text-align:center; font-size:18px;"><strong>พัสดุ:</strong> <span style="color:var(--primary);"><?php echo h($order['barcode']); ?></span></p>
        <?php if(!empty($error)) echo "<div class='alert alert-danger'>" . h($error) . "</div>"; ?>
        <form method="POST" enctype="multipart/form-data">
            <input type="hidden" name="csrf_token" value="<?php echo h(generate_csrf_token()); ?>">
            <div class="form-group"><label>อัปเดตสถานะล่าสุด</label>
                <select name="status" style="font-size:18px; padding:12px;">
                    <option value="delivering" <?php if($order['status']=='delivering') echo 'selected'; ?>>กำลังนำส่ง (Delivering)</option>
                    <option value="delivered" <?php if($order['status']=='delivered') echo 'selected'; ?>>ส่งสำเร็จแล้ว (Delivered)</option>
                </select>
            </div>
            <div class="form-group">
                <label>ถ่ายรูปหลักฐาน (JPG, PNG เท่านั้น)</label>
                <input type="file" name="proof_image" accept="image/jpeg, image/png" capture="environment" style="background:#fff; padding:5px;">
                <?php if($order['proof_image']): ?>
                    <p style="font-size:12px; color:green;">มีรูปหลักฐานแล้ว (อัปโหลดใหม่เพื่อทับของเดิม)</p>
                <?php endif; ?>
            </div>
            <div class="form-group">
                <label>ลายเซ็นผู้รับสินค้า (เซ็นผ่านหน้าจอ)</label>
                <div style="border:1px dashed #9ca3af; border-radius:8px; background:#fff; touch-action:none;">
                    <canvas id="sigCanvas" width="400" height="200" style="width:100%; height:200px; display:block;"></canvas>
                </div>
                <input type="hidden" name="signature_data" id="sigData">
                <button type="button" onclick="clearSig()" class="btn" style="margin-top: 10px; background: #6b7280; padding:5px 15px;">ล้างลายเซ็น</button>
                <?php if($order['signature_image']): ?>
                    <p style="font-size:12px; color:green;">มีลายเซ็นแล้ว (เซ็นใหม่เพื่อทับของเดิม)</p>
                <?php endif; ?>
            </div>
            <button type="submit" class="btn-success" style="width: 100%; margin-top: 15px; padding: 15px; font-size:18px;" id="submitBtn">ยืนยันบันทึกข้อมูลจัดส่ง</button>
            <div style="margin-top: 15px; text-align: center;"><a href="driver_dashboard.php" style="color: var(--danger); font-weight:bold; text-decoration:none;">< ย้อนกลับ</a></div>
        </form>
    </div>
</div>
<script>
var canvas = document.getElementById('sigCanvas');
var ctx = canvas.getContext('2d');
var drawing = false;

function getMousePos(canvas, evt) {
    var rect = canvas.getBoundingClientRect();
    var scaleX = canvas.width / rect.width;
    var scaleY = canvas.height / rect.height;
    var clientX = evt.clientX || (evt.touches && evt.touches[0].clientX);
    var clientY = evt.clientY || (evt.touches && evt.touches[0].clientY);
    return { x: (clientX - rect.left) * scaleX, y: (clientY - rect.top) * scaleY };
}

canvas.addEventListener('mousedown', function(e) { drawing = true; draw(e); });
canvas.addEventListener('touchstart', function(e) { e.preventDefault(); drawing = true; draw(e); }, {passive: false});
canvas.addEventListener('mouseup', function() { drawing = false; ctx.beginPath(); setSigData(); });
canvas.addEventListener('touchend', function() { drawing = false; ctx.beginPath(); setSigData(); });
canvas.addEventListener('mousemove', draw);
canvas.addEventListener('touchmove', function(e) { e.preventDefault(); draw(e); }, {passive: false});

function draw(e) {
    if(!drawing) return;
    var pos = getMousePos(canvas, e);
    ctx.lineWidth = 3; 
    ctx.lineCap = 'round'; 
    ctx.strokeStyle = '#000';
    ctx.lineTo(pos.x, pos.y); 
    ctx.stroke();
    ctx.beginPath(); 
    ctx.moveTo(pos.x, pos.y);
}

function setSigData() {
    var blank = document.createElement('canvas');
    blank.width = canvas.width;
    blank.height = canvas.height;
    if (canvas.toDataURL() !== blank.toDataURL()) {
        document.getElementById('sigData').value = canvas.toDataURL();
    }
}

function clearSig() {
    ctx.clearRect(0,0,canvas.width,canvas.height);
    document.getElementById('sigData').value = '';
}

document.querySelector('form').addEventListener('submit', function() {
    document.getElementById('submitBtn').disabled = true;
    document.getElementById('submitBtn').innerText = 'กำลังบันทึก...';
});
</script>
</body>
</html>