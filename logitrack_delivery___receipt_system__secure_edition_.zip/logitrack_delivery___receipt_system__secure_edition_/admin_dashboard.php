<?php
require 'config.php';
checkAuth('admin');

$stmt = $pdo->query("SELECT * FROM orders ORDER BY created_at DESC");
$orders = $stmt->fetchAll();
$csrf_token = generate_csrf_token();
?>
<!DOCTYPE html>
<html lang="th">
<head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0"><title>Admin Dashboard | LogiTrack</title><link rel="stylesheet" href="style.css"></head>
<body>
<div class="container">
    <div class="nav">
        <h2>ระบบจัดการหลังบ้าน (Admin)</h2>
        <div>
            <span style="margin-right: 10px;">ยินดีต้อนรับ, <?php echo h($_SESSION['name']); ?></span>
            <a href="logout.php" class="btn btn-danger">ออกจากระบบ</a>
        </div>
    </div>
    <?php display_flash(); ?>
    <div class="card">
        <div style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 10px; margin-bottom: 15px;">
            <h3 style="margin:0;">รายการคำสั่งจัดส่งทั้งหมด</h3>
            <a href="admin_create.php" class="btn btn-success">+ สร้างรายการใหม่</a>
        </div>
        <table>
            <thead>
                <tr>
                    <th>บาร์โค้ด</th>
                    <th>ผู้ส่ง</th>
                    <th>ผู้รับ</th>
                    <th>สถานะ</th>
                    <th>เวลาสร้าง</th>
                    <th>จัดการ</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach($orders as $row): ?>
                <tr>
                    <td><?php echo h($row['barcode']); ?></td>
                    <td><?php echo h($row['sender_dept']); ?></td>
                    <td><?php echo h($row['receiver_dept']); ?></td>
                    <td><span class="badge <?php echo h($row['status']); ?>"><?php echo h($row['status']); ?></span></td>
                    <td><?php echo h(thai_date($row['created_at'])); ?></td>
                    <td>
                        <a href="admin_edit.php?id=<?php echo h($row['id']); ?>" class="btn" style="padding: 5px 10px; font-size: 13px;">แก้ไข</a>
                        <form action="admin_delete.php" method="POST" style="display:inline;" onsubmit="return confirm('ยืนยันการลบข้อมูลนี้? การกระทำนี้ไม่สามารถย้อนกลับได้');">
                            <input type="hidden" name="csrf_token" value="<?php echo h($csrf_token); ?>">
                            <input type="hidden" name="id" value="<?php echo h($row['id']); ?>">
                            <button type="submit" class="btn btn-danger" style="padding: 5px 10px; font-size: 13px;">ลบ</button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; ?>
                <?php if(count($orders) === 0): ?>
                <tr><td colspan="6" style="text-align:center;">ยังไม่มีรายการจัดส่ง</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
</body>
</html>