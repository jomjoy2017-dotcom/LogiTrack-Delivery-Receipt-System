<?php
require 'config.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf_token($_POST['csrf_token'] ?? '');
    
    $name = trim($_POST['name']);
    $username = trim($_POST['username']);
    $password = $_POST['password'];
    $role = 'customer'; 
    
    if (strlen($password) < 8 || !preg_match("/[A-Za-z]/", $password) || !preg_match("/[0-9]/", $password)) {
        set_flash('danger', 'รหัสผ่านต้องมีอย่างน้อย 8 ตัวอักษร และประกอบด้วยตัวอักษรและตัวเลข');
    } else {
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);
        try {
            $stmt = $pdo->prepare("INSERT INTO users (username, password, role, name) VALUES (?, ?, ?, ?)");
            $stmt->execute([$username, $hashed_password, $role, $name]);
            set_flash('success', 'สมัครสมาชิกสำเร็จ กรุณาเข้าสู่ระบบ');
            header("Location: login.php");
            exit;
        } catch(PDOException $e) {
            if ($e->getCode() == 23000) {
                set_flash('danger', 'ชื่อผู้ใช้นี้มีในระบบแล้ว');
            } else {
                error_log("Registration error: " . $e->getMessage());
                set_flash('danger', 'เกิดข้อผิดพลาดของระบบ โปรดลองใหม่ภายหลัง');
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="th">
<head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0"><title>สมัครสมาชิก | LogiTrack</title><link rel="stylesheet" href="style.css"></head>
<body>
<div class="container" style="max-width: 400px; margin-top: 5vh;">
    <div class="card">
        <h2 style="text-align: center;">สมัครสมาชิก (ลูกค้า)</h2>
        <?php display_flash(); ?>
        <form method="POST">
            <input type="hidden" name="csrf_token" value="<?php echo h(generate_csrf_token()); ?>">
            <div class="form-group"><label>ชื่อ-นามสกุล</label><input type="text" name="name" required></div>
            <div class="form-group"><label>ชื่อผู้ใช้ (Username)</label><input type="text" name="username" required></div>
            <div class="form-group"><label>รหัสผ่าน (ตัวอักษรและตัวเลข 8+ ตัว)</label><input type="password" name="password" minlength="8" required></div>
            <button type="submit" class="btn-success" style="width: 100%;">ลงทะเบียน</button>
        </form>
        <p style="text-align: center; margin-top: 15px;"><a href="login.php">กลับไปหน้าเข้าสู่ระบบ</a></p>
    </div>
</div>
</body>
</html>