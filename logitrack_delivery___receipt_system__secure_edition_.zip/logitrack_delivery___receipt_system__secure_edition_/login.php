<?php
require 'config.php';

if (!isset($_SESSION['login_attempts'])) $_SESSION['login_attempts'] = 0;
if (!isset($_SESSION['login_last_attempt'])) $_SESSION['login_last_attempt'] = time();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf_token($_POST['csrf_token'] ?? '');
    
    if ($_SESSION['login_attempts'] >= 5 && (time() - $_SESSION['login_last_attempt']) < 300) {
        set_flash('danger', 'พยายามเข้าระบบผิดพลาดเกินกำหนด กรุณารอ 5 นาที');
    } else {
        $username = trim($_POST['username']);
        $password = $_POST['password'];
        
        $stmt = $pdo->prepare("SELECT * FROM users WHERE username = ? LIMIT 1");
        $stmt->execute([$username]);
        $user = $stmt->fetch();
        
        if ($user && password_verify($password, $user['password'])) {
            session_regenerate_id(true);
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['role'] = $user['role'];
            $_SESSION['name'] = $user['name'];
            $_SESSION['login_attempts'] = 0;
            header("Location: index.php");
            exit;
        } else {
            $_SESSION['login_attempts']++;
            $_SESSION['login_last_attempt'] = time();
            set_flash('danger', 'ชื่อผู้ใช้หรือรหัสผ่านไม่ถูกต้อง');
        }
    }
}
?>
<!DOCTYPE html>
<html lang="th">
<head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0"><title>เข้าสู่ระบบ | LogiTrack</title><link rel="stylesheet" href="style.css"></head>
<body>
<div class="container" style="max-width: 400px; margin-top: 10vh;">
    <div class="card">
        <h2 style="text-align: center;">เข้าสู่ระบบ LogiTrack</h2>
        <?php display_flash(); ?>
        <form method="POST">
            <input type="hidden" name="csrf_token" value="<?php echo h(generate_csrf_token()); ?>">
            <div class="form-group"><label>ชื่อผู้ใช้</label><input type="text" name="username" required autofocus></div>
            <div class="form-group"><label>รหัสผ่าน</label><input type="password" name="password" required></div>
            <button type="submit" style="width: 100%;">เข้าสู่ระบบ</button>
        </form>
        <p style="text-align: center; margin-top: 15px;"><a href="register.php">สมัครสมาชิกใหม่</a></p>
    </div>
</div>
</body>
</html>