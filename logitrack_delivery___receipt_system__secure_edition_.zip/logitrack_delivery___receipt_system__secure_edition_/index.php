<?php
require 'config.php';

if (!empty($_SESSION['role'])) {
    if ($_SESSION['role'] === 'admin') { header("Location: admin_dashboard.php"); exit; }
    if ($_SESSION['role'] === 'driver') { header("Location: driver_dashboard.php"); exit; }
}

$order = null;
if (!empty($_GET['tracking_code'])) {
    $tracking_code = trim($_GET['tracking_code']);
    $stmt = $pdo->prepare("SELECT * FROM orders WHERE barcode = ?");
    $stmt->execute([$tracking_code]);
    $order = $stmt->fetch();
    if (!$order) {
        set_flash('warning', 'ไม่พบข้อมูลพัสดุจากรหัสนี้ โปรดตรวจสอบความถูกต้อง');
    }
}
?>
<!DOCTYPE html>
<html lang="th">
<head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0"><title>ติดตามสถานะสินค้า | LogiTrack</title><link rel="stylesheet" href="style.css"></head>
<body>
<div class="container">
    <div class="nav">
        <h2>LogiTrack Delivery</h2>
        <div>
            <?php if(empty($_SESSION['user_id'])): ?>
                <a href="login.php" class="btn">เข้าสู่ระบบ</a>
            <?php else: ?>
                <a href="logout.php" class="btn btn-danger">ออกจากระบบ</a>
            <?php endif; ?>
        </div>
    </div>
    <?php display_flash(); ?>
    <div class="card">
        <h3>ติดตามพัสดุ / Track Your Order</h3>
        <form method="GET" style="display: flex; gap: 10px; flex-wrap: wrap;">
            <input type="text" name="tracking_code" placeholder="กรอกรหัสบาร์โค้ด (เช่น TRK-...)" required style="flex: 1; min-width: 200px;" value="<?php echo h($_GET['tracking_code'] ?? ''); ?>">
            <button type="submit">ค้นหาสถานะ</button>
        </form>
    </div>
    <?php if(!empty($_GET['tracking_code']) && $order): ?>
        <div class="card">
            <h3>ข้อมูลพัสดุ: <?php echo h($order['barcode']); ?></h3>
            <p><strong>สถานะปัจจุบัน:</strong> <span class="badge <?php echo h($order['status']); ?>"><?php echo h(strtoupper($order['status'])); ?></span></p>
            <p><strong>ผู้ส่ง (แผนก):</strong> <?php echo h($order['sender_dept']); ?> (โทร: <?php echo h(mask_phone($order['sender_phone'])); ?>)</p>
            <p><strong>ผู้รับ (แผนก):</strong> <?php echo h($order['receiver_dept']); ?> (โทร: <?php echo h(mask_phone($order['receiver_phone'])); ?>)</p>
            <p><strong>รายละเอียดสินค้า:</strong> <?php echo nl2br(h($order['product_details'])); ?></p>
            <p><strong>อัปเดตล่าสุดเวลา:</strong> <?php echo h(thai_date($order['updated_at'])); ?></p>
            
            <?php if($order['proof_image']): ?>
                <hr style="margin: 20px 0; border:0; border-top:1px solid #eee;">
                <h4>รูปภาพหลักฐานการจัดส่ง</h4>
                <img src="uploads/<?php echo h($order['proof_image']); ?>" class="img-preview" alt="Proof">
            <?php endif; ?>

            <?php if($order['signature_image']): ?>
                <hr style="margin: 20px 0; border:0; border-top:1px solid #eee;">
                <h4>ลายเซ็นผู้รับสินค้า</h4>
                <img src="uploads/<?php echo h($order['signature_image']); ?>" class="img-preview" style="background: #fff; border: 1px solid #ccc; max-height: 150px;" alt="Signature">
            <?php endif; ?>
        </div>
    <?php endif; ?>
</div>
</body>
</html>