<?php
require 'config.php';
checkAuth('driver');

$stmt = $pdo->query("SELECT * FROM orders WHERE status IN ('pending', 'delivering') ORDER BY created_at ASC");
$orders = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="th">
<head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0"><title>Driver Dashboard | LogiTrack</title><link rel="stylesheet" href="style.css"></head>
<body>
<div class="container">
    <div class="nav">
        <h2>ระบบพนักงานจัดส่ง (Driver)</h2>
        <div>
            <span style="margin-right:10px;">คนขับ: <?php echo h($_SESSION['name']); ?></span>
            <a href="logout.php" class="btn btn-danger">ออก</a>
        </div>
    </div>
    <?php display_flash(); ?>
    <div class="card">
        <h3>งานที่ต้องดำเนินการจัดส่ง</h3>
        <div style="display:grid; gap: 15px;">
            <?php foreach($orders as $row): ?>
            <div style="border: 1px solid var(--border); padding: 15px; border-radius: 8px; background: #fafafa;">
                <div style="display:flex; justify-content:space-between; align-items:center;">
                    <h4 style="margin:0; color:var(--primary);"><?php echo h($row['barcode']); ?></h4>
                    <span class="badge <?php echo h($row['status']); ?>"><?php echo h(strtoupper($row['status'])); ?></span>
                </div>
                <hr style="border:0; border-top:1px solid #eee; margin:10px 0;">
                <p style="margin:5px 0;"><strong>รับจาก:</strong> <?php echo h($row['sender_dept']); ?> (โทร: <?php echo h($row['sender_phone']); ?>)</p>
                <p style="margin:5px 0;"><strong>ส่งไปที่:</strong> <?php echo h($row['receiver_dept']); ?> (โทร: <?php echo h($row['receiver_phone']); ?>)</p>
                <p style="margin:5px 0;"><strong>รายละเอียด:</strong> <?php echo h($row['product_details']); ?></p>
                <a href="driver_update.php?id=<?php echo h($row['id']); ?>" class="btn btn-success" style="display:block; margin-top: 15px; width: 100%; text-align:center;">อัปเดตสถานะ / ตรวจรับ (e-POD)</a>
            </div>
            <?php endforeach; ?>
            <?php if(count($orders) === 0): ?>
                <p style="text-align:center; color:#6b7280;">-- ขณะนี้ไม่มีงานจัดส่งค้างอยู่ --</p>
            <?php endif; ?>
        </div>
    </div>
</div>
</body>
</html>