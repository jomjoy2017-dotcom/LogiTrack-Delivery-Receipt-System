<?php
require 'config.php';
checkAuth('admin');

$barcode = 'TRK-' . strtoupper(substr(bin2hex(random_bytes(4)), -6)) . rand(10,99);
$auto_time = date('Y-m-d H:i:s');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf_token($_POST['csrf_token'] ?? '');
    
    $b = trim($_POST['barcode']);
    $s_dept = trim($_POST['sender_dept']);
    $s_phone = trim($_POST['sender_phone']);
    $r_dept = trim($_POST['receiver_dept']);
    $r_phone = trim($_POST['receiver_phone']);
    $details = trim($_POST['product_details']);
    
    if (!validate_phone($s_phone) || !validate_phone($r_phone)) {
        set_flash('danger', 'กรุณากรอกเบอร์โทรศัพท์ให้ถูกต้อง (เฉพาะตัวเลข 9-10 หลัก)');
    } else {
        try {
            $stmt = $pdo->prepare("INSERT INTO orders (barcode, sender_dept, sender_phone, receiver_dept, receiver_phone, product_details) VALUES (?, ?, ?, ?, ?, ?)");
            if ($stmt->execute([$b, $s_dept, $s_phone, $r_dept, $r_phone, $details])) {
                set_flash('success', 'บันทึกรายการจัดส่งใหม่เรียบร้อยแล้ว');
                header("Location: admin_dashboard.php");
                exit;
            }
        } catch(PDOException $e) {
            error_log("Create Order Error: " . $e->getMessage());
            set_flash('danger', 'เกิดข้อผิดพลาดในการบันทึกข้อมูล');
        }
    }
}
?>
<!DOCTYPE html>
<html lang="th">
<head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0"><title>สร้างรายการใหม่ | LogiTrack</title><link rel="stylesheet" href="style.css"></head>
<body>
<div class="container">
    <div class="card" style="max-width: 600px; margin: 0 auto;">
        <h2>เพิ่มรายการจัดส่งใหม่ (Create Order)</h2>
        <?php display_flash(); ?>
        <form method="POST">
            <input type="hidden" name="csrf_token" value="<?php echo h(generate_csrf_token()); ?>">
            <div class="form-group"><label>1. รหัสสินค้า (Barcode)</label><input type="text" name="barcode" value="<?php echo h($barcode); ?>" readonly style="background:#f3f4f6;"></div>
            <div class="form-group"><label>2. ชื่อแผนกส่ง</label><input type="text" name="sender_dept" required placeholder="เช่น แผนกบัญชี, สโตร์หลัก"></div>
            <div class="form-group"><label>3. เบอร์โทรศัพท์ผู้ส่ง</label><input type="text" name="sender_phone" required pattern="[0-9]{9,10}" placeholder="ตัวเลขเท่านั้น"></div>
            <div class="form-group"><label>4. ชื่อแผนกผู้รับ</label><input type="text" name="receiver_dept" required placeholder="เช่น แผนกบุคคล, ฝ่ายขาย"></div>
            <div class="form-group"><label>5. เบอร์โทรศัพท์ผู้รับ</label><input type="text" name="receiver_phone" required pattern="[0-9]{9,10}" placeholder="ตัวเลขเท่านั้น"></div>
            <div class="form-group"><label>6. เวลาสร้างเอกสาร</label><input type="text" value="<?php echo h($auto_time); ?>" disabled style="background:#f3f4f6;"></div>
            <div class="form-group"><label>7. รายละเอียดสินค้า</label><textarea name="product_details" rows="4" required placeholder="จำนวน, ประเภท, น้ำหนัก ฯลฯ"></textarea></div>
            <div style="display:flex; gap:10px; margin-top:20px;">
                <button type="submit" class="btn-success" style="flex:1;">บันทึกข้อมูล</button>
                <a href="admin_dashboard.php" class="btn btn-danger" style="flex:1; text-align:center;">ยกเลิก</a>
            </div>
        </form>
    </div>
</div>
</body>
</html>